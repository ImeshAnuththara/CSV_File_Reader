import mysql.connector
import csv
import os
import pandas as pd
from mysql.connector import Error

def databaseconnection():
    try:
        connection = mysql.connector.connect(host='localhost',
                                          database='renewableenergy',
                                             user='root',
                                             password='Root@123')
        cursor = connection.cursor()
        mySql_Create_Table_Query = """CREATE TABLE Private_Wind_Generation (
                                                             ID varchar(10),
                                                             Year varchar(4),
                                                             Month varchar(10),
                                                             Electricity_Generation varchar(10),
                                                             Total_Cost varchar(10),
                                                             Wind_Unit_Cost varchar(10),
                                                             PRIMARY KEY (Id)) """

        #sql= """CREATE TABLE weather_data (
        #                              ID varchar(10),
        #                              Year varchar(4),
        #                              Location varchar(20),
        #                              Latitude varchar(10),
        #                              Longitude varchar(10),
        #                              Annual_Avg_Temp varchar(10),
        #                              Annual_Avg_Wind_Speed varchar(10),
        #                              Annual_Rain_Precipitation varchar(10),
        #                              PRIMARY KEY (Id)) """

        # mySql_Create_Table_Query = """CREATE TABLE weather_data (
        #                                                      Id varchar(11) NOT NULL,
        #                                                      Year varchar(4),
        #                                                      Month varchar(10),
        #                                                      CEB_Generation varchar(10),
        #                                                      Oil_Consumption varchar(10),
        #                                                      Fuel_Cost varchar(10),
        #                                                      Monthly_Unit_Cost varchar(10),
        #                                                      PRIMARY KEY (Id)) """

        #mySql_Create_Table_Query = """CREATE TABLE government_hydro_generation (
        #                                             Id varchar(11) NOT NULL,
        #                                             Year varchar(4),
        #                                             Month varchar(10),
        #                                             Electricity_Generation varchar(10),
        #                                             Station_Consumption varchar(10),
        #                                             Net_Generation varchar(10),
        #                                             PRIMARY KEY (Id)) """

        #mySql_Create_Table_Query = """CREATE TABLE government_coal_generation (
        #                                     Id varchar(11) NOT NULL,
        #                                     Year varchar(4),
        #                                     Month varchar(10),
        #                                     Electricity_Generation varchar(10),
        #                                     Purchased_cost varchar(10),
        #                                     Unit_Cost varchar(10),
        #                                     PRIMARY KEY (Id)) """

        #mySql_Create_Table_Query = """CREATE TABLE Solar_Power (
        #                                             Id varchar(11) NOT NULL,
        #                                             Year varchar(4),
        #                                             Month varchar(10),
        #                                             Generation varchar(10),
        #                                             Purchased_cost varchar(10),
        #                                             Unit_Cost varchar(10),
        #                                             PRIMARY KEY (Id)) """

        #mySql_Create_Table_Query = """CREATE TABLE Government_fuel_purchased (
        #                                             Id varchar(11) NOT NULL,
        #                                             Year varchar(4),
        #                                             Month varchar(10),
        #                                             CEB_Generation varchar(10),
        #                                             Oil_Consumption varchar(10),
        #                                             Fuel_Cost varchar(10),
        #                                             Monthly_Unit_Cost varchar(10),
        #                                             PRIMARY KEY (Id)) """
        #mySql_Create_Table_Query = """CREATE TABLE private_fuel_purchased (
        #                                             Id varchar(11) NOT NULL,
        #                                             Year varchar(4),
        #                                             Month varchar(10),
        #                                             Private varchar(10),
        #                                             Total_Cost varchar(10),
        #                                             Avg_Purches_Cost varchar(10),
        #                                             PRIMARY KEY (Id)) """

        #result = cursor.execute(mySql_Create_Table_Query)
        print("Table created successfully ")

        mySql_Select_Database_Query = """Use renewableenergy"""
        result2 = cursor.execute(mySql_Select_Database_Query)
        print("Database Selected successfully ")

        mySql_Insert_Table_Query = """INSERT INTO private_fuel_purchased(Id, Year, Month, CEB_Generation, Oil_Consumption,Fuel_Cost, Monthly_Unit_Cost)
        VALUES(?, ?, ?, ?, ?, ?,?)"""
        result3 = cursor.execute(mySql_Insert_Table_Query)
        connection.commit()
        print("Enter data successfully ")

    except mysql.connector.Error as error:
        print("Failed to create table in MySQL: {}".format(error))
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

#def insertdata():

