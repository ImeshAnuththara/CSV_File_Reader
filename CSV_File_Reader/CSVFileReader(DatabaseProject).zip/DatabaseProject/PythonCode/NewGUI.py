import tkinter as tk
from tkinter import *
import pandas as pd
from tkinter import filedialog
import ImageTk
import os
from PIL import Image

root = tk.Tk()
root.title("Select Your CSV File")
root.resizable(False, False)
root.geometry("500x600")

#root.title("Use of Sustainable Energy for a Stable Economy")
#canvas = tk.Canvas(root, width=400, height=600)
#canvas.grid(columnspan=3, rowspan=20)
root.configure(bg="#042424")
heading=Label(root,font="Releway", fg="white",text="Use of Sustainable Energy for a Stable Economy",bg="#042424")
#heading.grid(rows=1,column=1)
heading.place(x=80,y=10)


##Image
logo = Image.open("CSV.jpg")
logo = ImageTk.PhotoImage(logo)
logo_label = tk.Label(image=logo)
#logo_label.place(x=0, y=0, relwidth=1, relheight=1)
#logo_label.image=logo
#logo_label.grid(column=1,row=0)

##text
text = tk.Label(root, text="Use of Sustainable Energy for a Stable Economy", font="Releway", bg="#042424", fg="white")
#text.grid(column=1, row=0)

filepath = filedialog.askopenfilename(title="choose a file", filetype=[("CSV file", ".csv")])


def open_file():
    button_label.set("loading...")
    print(filepath)
    text2.setvar(filepath)
    if not os.access(filepath, os.W_OK):
        button_label.set("Browse")
    else:
        with open(filepath, 'r') as file:
            # reader = csv.reader(file)
            reader = pd.read_csv(file)
            print(reader.columns)
            #print(reader.nrows)

            button_label.set("Browse")

#button 1

button_label = tk.StringVar()
button_label.set("Select Your File")
button = tk.Button(root, textvariable=button_label, command=lambda: open_file(), font="Raleway", bg="#20bebe",
                   fg="black", height=1, width=15)
#button.grid(column=1, row=2)
button.place(x=20,y=90)

##text
displaylink=tk.StringVar()
displaylink.set(filepath)
text2 = Label(root, font="Releway",textvariable=displaylink, width=35)
text2.place(x=170,y=95)

entry_1 = tk.Entry(root,font="Releway",textvariable=displaylink, width=24)
#entry_1.place(x=250,y=95)

#button 2

button_label2 = tk.StringVar()
button_label2.set("Browse")
button2 = tk.Button(root, textvariable=button_label2, font="Raleway", bg="#20bebe",
                   fg="black", height=1, width=15)
#button2.grid(column=1, row=3)
button2.place(x=20,y=130)

root.mainloop()