import csv
import MySQLdb
import pymysql
import tkinter as tk
import pandas as pd
from tkinter import filedialog
from Database_con import*
import os
import ImageTk
from PIL import Image
import mysql.connector


root = tk.Tk()
root.title("Select Your CSV File")
root.resizable(False, False)
root.geometry("400x500")
canvas = tk.Canvas(root, width=400, height=500)
canvas.grid(columnspan=3, rowspan=10)

##Image
logo = Image.open("CSV.jpg")
logo = ImageTk.PhotoImage(logo)
logo_label = tk.Label(image=logo)
logo_label.place(x=0, y=0, relwidth=1, relheight=1)
# logo_label.image=logo
# logo_label.grid(column=1,row=0)

##text
text = tk.Label(root, text="Use of Sustainable Energy for a Stable Economy", font="Releway", bg="#042424", fg="white")
text.grid(column=1, row=1)


filepath = filedialog.askopenfilename(title="choose a file", filetype=[("CSV file", ".csv")])
def open_file():
    button_label.set("loading...")
    print(filepath)
    if not os.access(filepath, os.W_OK):
        button_label.set("Browse")
    else:
        with open(filepath, 'r') as file:
            # reader = csv.reader(file)
            reader = pd.read_csv(file)
            # for i, row in reader.iterrows():
                # print(row)
            #print(reader.nrows)
            dataupload()
            button_label.set("Browse")

## database

def dataupload():
    try:
        connection = mysql.connector.connect(host='127.0.0.1', port=3308,
                                             database='RenewableDB',
                                             user='root',
                                             password='')
        cursor = connection.cursor()
        mySql_Create_Table_Query = """CREATE TABLE CEB_Generation (
                                                     Year varchar(4),
                                                     Demand varchar(10),
                                                     Hydro varchar(10),
                                                     Thermal varchar(10),
                                                     Other_Renewable varchar(10),
                                                     Total varchar(10))"""
        result = cursor.execute(mySql_Create_Table_Query)
        print("Table created successfully ")

        #mySql_Select_Database_Query = """Use test"""
        #result2 = cursor.execute(mySql_Select_Database_Query)
        print("Database Selected successfully ")
        with open(filepath, 'r') as file:
            reader = pd.read_csv(file)
            for i, row in reader.iterrows():
            #mySql_Insert_Table_Query =
             result3 = cursor.execute("""INSERT INTO CEB_Generation(Year, Demand, Hydro, Thermal, Other_Renewable,Total)
             VALUES(%s,%s,%s,%s,%s,%s)""",tuple(row))

            connection.commit()
        print("Enter data successfully ")

    except mysql.connector.Error as error:
        print("Failed to create table in MySQL: {}".format(error))
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

##button

button_label = tk.StringVar()
button_label.set("Browse")
button = tk.Button(root, textvariable=button_label, command=lambda: open_file(), font="Raleway", bg="#20bebe",
                   fg="black", height=1, width=15)
button.grid(column=1, row=8)
root.mainloop()
