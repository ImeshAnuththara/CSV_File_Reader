print("hello")
def op(rows):
    print(rows)


def input():
    rows = "123"
    op(rows)

input()